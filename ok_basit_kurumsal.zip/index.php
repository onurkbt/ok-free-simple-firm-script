<?php 
include 'admin/islemler/veritabani.php';
$ayarsor=$db->prepare("SELECT * FROM sayfa_ayarlari");
$ayarsor->execute();
$ayarcek=$ayarsor->fetch(PDO::FETCH_ASSOC);
?>


<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title><?php echo $ayarcek['baslik']; ?></title>
  <meta content="" name="description">
  <meta content="" name="keywords">

  <!-- Favicons -->
  <link href="assets/img/favicon.png" rel="icon">
  <link href="assets/img/apple-touch-icon.png" rel="apple-touch-icon">

  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Raleway:300,300i,400,400i,600,600i,700,700i" rel="stylesheet">

  <!-- Vendor CSS Files -->
  <link href="assets/vendor/aos/aos.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
  <link href="assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
  <link href="assets/vendor/glightbox/css/glightbox.min.css" rel="stylesheet">
  <link href="assets/vendor/swiper/swiper-bundle.min.css" rel="stylesheet">

  <!-- Template Main CSS File -->
  <link href="assets/css/style.css" rel="stylesheet">
  <link href="../admin/islemler/resimler/">

  <!-- =======================================================
  * Template Name: Ninestars - v4.9.0
  * Template URL: https://bootstrapmade.com/ninestars-free-bootstrap-3-theme-for-creative/
  * Author: BootstrapMade.com
  * License: https://bootstrapmade.com/license/
  ======================================================== -->
</head>

<body>

  <!-- ======= Header ======= -->
  <header id="header" class="fixed-top d-flex align-items-center">
    <div class="container d-flex align-items-center justify-content-between">

      <div class="logo">
        <h1 class="text-light"><a href="index.php"><span><?php echo $ayarcek['baslik']; ?></span></a></h1>
        <!-- Uncomment below if you prefer to use an image logo -->
        <!-- <a href="index.html"><img src="assets/img/logo.png" alt="" class="img-fluid"></a>-->
      </div>

      <nav id="navbar" class="navbar">
        <ul>
          <li><a class="nav-link scrollto active" href="#hero">Anasayfa</a></li>
          <li><a class="nav-link scrollto" href="#about">Hakkımızda</a></li>
          <li><a class="nav-link scrollto" href="#services">Hizmetlerimiz</a></li>
          <li><a class="nav-link scrollto" href="#portfolio">Galeri</a></li>
          <li><a class="nav-link scrollto" href="#faq">S.S.S</a></li>
          <li><a class="nav-link scrollto" href="#clients">Referanslarımız</a></li>
          <li><a class="getstarted scrollto" href="#contact">İletişim</a></li>
        </ul>
        <i class="bi bi-list mobile-nav-toggle"></i>
      </nav><!-- .navbar -->

    </div>
  </header><!-- End Header -->

  <!-- ======= Hero Section ======= -->
  <section id="hero" class="d-flex align-items-center">
  <?php 
$slidersor=$db->prepare("SELECT * FROM slider_ayarlari");
$slidersor->execute();
$slidercek=$slidersor->fetch(PDO::FETCH_ASSOC);
?>
    <div class="container">
      <div class="row gy-4">
        <div class="col-lg-6 order-2 order-lg-1 d-flex flex-column justify-content-center">
          <h1><?php echo $slidercek['slider_baslik']; ?></h1>
          <h2><?php echo $slidercek['slider_aciklama']; ?></h2>
          <div>
            <a href="#services" class="btn-get-started scrollto">Hizmetlerimiz</a>
          </div>
        </div>
        <div class="col-lg-6 order-1 order-lg-2 hero-img">
        <?php 
        $slidercek=$db->prepare("SELECT * FROM slider_ayarlari");
        $slidercek->execute();
        if($slidercek->rowCount()){ 
          foreach($slidercek as $row){ 

    
        ?>   
        <img src="admin/islemler/<?php echo $row['slider_resim']; ?>" alt="" class="img-fluid animated" width="500" height="300">  
         <?php
          }
          ?>
           <?php
          }
          ?>


          
        </div>
      </div>
    </div>

  </section><!-- End Hero -->

  <main id="main">

    <!-- ======= About Section ======= -->
    <section id="about" class="about">
      <div class="container">

        <div class="row justify-content-between">
          <div class="col-lg-5 d-flex align-items-center justify-content-center about-img">
          <?php 
        $hakkimizdacek=$db->prepare("SELECT * FROM hakkimizda_ayarlari");
        $hakkimizdacek->execute();
        if($hakkimizdacek->rowCount()){ 
          foreach($hakkimizdacek as $row){ 

    
        ?>   
        <img src="admin/islemler/<?php echo $row['hakkimizda_resim']; ?>" alt="" class="img-fluid animated" width="500" height="300">  
         <?php
          }
          ?>
           <?php
          }
          ?>
            
          </div>
<?php 
$hakkimizdasor=$db->prepare("SELECT * FROM hakkimizda_ayarlari");
$hakkimizdasor->execute();
$hakkimizdacek=$hakkimizdasor->fetch(PDO::FETCH_ASSOC);
?>
          <div class="col-lg-6 pt-5 pt-lg-0">
            <h3 data-aos="fade-up"><?php echo $hakkimizdacek['hakkimizda_baslik']?></h3>
            <p data-aos="fade-up" data-aos-delay="100"><?php echo $hakkimizdacek['hakkimizda_aciklama']; ?></p> 
          </div>
        </div>

      </div>
    </section><!-- End About Section -->

    <!-- ======= Services Section ======= -->
   
    <section id="services" class="services section-bg">
      <div class="container" data-aos="fade-up">

        <div class="section-title">
          <p>Hizmetlerimiz</p>
        </div>
        <div class="row">
          <?php
         $hizmetsor=$db->prepare("SELECT * FROM hizmet_ayarlari");
         $hizmetsor->execute();
          while ($hizmetcek=$hizmetsor->fetch(PDO::FETCH_ASSOC)) 
          {
          ?>
        <div class="col-md-6 col-lg-3 d-flex align-items-stretch aos-init aos-animate" data-aos="zoom-in" data-aos-delay="100">
          <div class="icon-box"><div class="icon"><i class='bx bxs-caret-down-circle' ></i></div>
          <h4 class="title"><a href=""><?php echo $hizmetcek['hizmet_baslik'] ?></a></h4>
          <p class="description"><?php echo $hizmetcek['hizmet_aciklama'] ?></p>
        </div>
      </div>
         <?php 
         }
          ?>
        </div>
    </section><!-- End Services Section -->

    <!-- ======= Portfolio Section ======= -->
    <section id="portfolio" class="portfolio">
      <div class="container" data-aos="fade-up">

        <div class="section-title">
          <h2></h2>
          <p>Galeri</p>
        </div>

        <div class="row" data-aos="fade-up" data-aos-delay="100">
          <div class="col-lg-12">
            <ul id="portfolio-flters">
              <li data-filter="*" class="filter-active"></li>
            </ul>
          </div>
        </div>

        <div class="row portfolio-container" data-aos="fade-up" data-aos-delay="200">
        <?php 
        $galericek=$db->prepare("SELECT * FROM galeri_ayarlari");
        $galericek->execute();
        if($galericek->rowCount()){ 
          foreach($galericek as $row){ 

    
        ?>   
          <div class="col-lg-4 col-md-6 portfolio-item filter-app">
            <div class="portfolio-wrap">
              <img src="admin/islemler/<?php echo $row['galeri_resim']; ?>" class="img-fluid" alt="">
              <div class="portfolio-links">
                <a href="admin/islemler/<?php echo $row['galeri_resim']; ?>" data-gallery="portfolioGallery" class="portfolio-lightbox" title=""><i class="bi bi-plus"></i></a>
              </div>
            </div>
          </div>
          
          <?php } 
          }?>        
        </div>
      </div>
    </section><!-- End Portfolio Section -->

    <!-- ======= F.A.Q Section ======= -->
    <section id="faq" class="faq section-bg">
      <div class="container" data-aos="fade-up">

        <div class="section-title">
          <h2></h2>
          <p>Sıkça Sorulan Sorular</p>
        </div>

        <ol class="faq-list" data-aos="fade-up" data-aos-delay="100">
<?php 

$ssssor=$db->prepare("SELECT * FROM sss_ayarlari");
$ssssor->execute();
while ($ssscek=$ssssor->fetch(PDO::FETCH_ASSOC)) 
{
?>

<li>
            <div data-bs-toggle="collapse" href="#soru<?php echo $ssscek['sss_id'];?>" class="collapsed question"><?php echo $ssscek['sss_soru'];?> <i class="bi bi-chevron-down icon-show"></i><i class="bi bi-chevron-up icon-close"></i></div>
            <div id="soru<?php echo $ssscek['sss_id'];?>" class="collapse" data-bs-parent=".faq-list">
              <p>
              <?php echo $ssscek['sss_cevap'];?>              
            </p>
            </div>
          </li>

  <?php 
  }
  ?>
        </ul>
      </div>
    </section><!-- End F.A.Q Section -->



     
<!-- ======= Clients Section ======= -->
    <section id="clients" class="clients section-bg">
      <div class="container" data-aos="fade-up">

        <div class="section-title">
          <p>Referanslar</p>
        </div>
        <div class="clients-slider swiper" data-aos="fade-up" data-aos-delay="100">
          <div class="swiper-wrapper align-items-center">
        <?php 

$ssscek=$db->prepare("SELECT * FROM referans_ayarlari ");
$ssscek->execute();
if($ssscek->rowCount()){ 
 foreach($ssscek as $row){ 

?> 
<div class="swiper-slide"><img src="admin/islemler/<?php echo $row['referans_logo'];?>" class="img-fluid" alt=""></div>                 
<?php
  }
}
?>
</div>
</div>
      </div>
    </section><!-- End Clients Section -->




    <!-- ======= Contact Us Section ======= -->
    <section id="contact" class="contact">
      <div class="container" data-aos="fade-up">

        <div class="section-title">
          <h2>İletişim Bilgileri</h2>
          <p>Bize Ulaşın</p>
        </div>

        <div class="row">

          <div class="col-lg-5 d-flex align-items-stretch" data-aos="fade-up" data-aos-delay="100">
            <div class="info">
              <div class="address">
                <i class="bi bi-geo-alt"></i>
                <h4>Adres:</h4>
                <p><?php echo $ayarcek['adres']; ?> </p>
              </div>

              <div class="email">
                <i class="bi bi-envelope"></i>
                <h4>E-Posta:</h4>
                <p><?php echo $ayarcek['eposta']; ?> </p>
              </div>

              <div class="phone">
                <i class="bi bi-phone"></i>
                <h4>Telefon:</h4>
                <p><?php echo $ayarcek['tel']; ?> </p>
              </div>

              <iframe src="<?php echo $ayarcek['harita']; ?>" frameborder="0" style="border:0; width: 100%; height: 290px;" allowfullscreen></iframe>
            </div>

          </div>
<?php 
$mesajsor=$db->prepare("SELECT * FROM mesajlar");
$mesajsor->execute();
$mesajcek=$mesajsor->fetch(PDO::FETCH_ASSOC);

?>


          <div class="col-lg-7 mt-5 mt-lg-0 d-flex align-items-stretch">
            <form action="admin/islemler/islem.php" method="POST" class="mesaj" >
              <div class="row">
                <div class="form-group col-md-6">
                  <label for="name">Adınız</label>
                  <input type="text" name="mesajlar_isim" class="form-control"  required>
                </div>
                <div class="form-group col-md-6 mt-3 mt-md-0">
                  <label for="name">E-Posta</label>
                  <input type="email" class="form-control" name="mesajlar_mail" required>
                </div>
              </div>
              <div class="form-group mt-3">
                <label for="name">Konu</label>
                <input type="text" class="form-control" name="mesajlar_konu"  required>
              </div>
              <div class="form-group mt-3">
                <label for="name">Mesaj</label>
                <textarea class="form-control" name="mesajlar_mesaj"></textarea>
              </div>
              
              <div class="merkez">
              <button  name="mesajgonder" class="mesajbutonu" type="submit">Gönder</button></div>

            </form>
                
          </div>
      </div>
    </section><!-- End Contact Us Section -->

  </main><!-- End #main -->

  <!-- ======= Footer ======= -->
  <footer id="footer">

    <div class="footer-newsletter">
      <div class="container">
        <div class="row justify-content-center">
          <div class="col-lg-6">
            <h4><?php echo $ayarcek['slogan']; ?> </h4>
          </div>
        </div>
      </div>
    </div>

    <div class="footer-top">
      <div class="container">
        <div class="row">

          <div class="col-lg-3 col-md-6 footer-contact">
            <h3><?php echo $ayarcek['baslik']; ?> </h3>
            <p>
              <strong>Adres:</strong> <?php echo $ayarcek['adres']; ?> <br>
              <strong>Telefon:</strong> <?php echo $ayarcek['tel']; ?> <br>
              <strong>E-Posta</strong> <?php echo $ayarcek['eposta']; ?> <br>
            </p>
          </div>

          <div class="col-lg-3 col-md-6 footer-links">
            <h4>Web Sitesi İçeriği</h4>
            <ul>
            <li><a class="nav-link scrollto active" href="#hero">Anasayfa</a></li>
            <li><a class="nav-link scrollto" href="#about">Hakkımızda</a></li>
            <li><a class="nav-link scrollto" href="#services">Hizmetlerimiz</a></li>
            <li><a class="nav-link scrollto" href="#portfolio">Galeri</a></li>
            <li><a class="getstarted scrollto" href="#contact">İletişim</a></li>
            </ul>
          </div>

          <div class="col-lg-3 col-md-6 footer-links">
            <h4>Diğer</h4>
            <ul>
            <li><a class="nav-link scrollto" href="#faq">S.S.S</a></li>
            <li><a class="nav-link scrollto" href="#clients">Referanslarımız</a></li>
            </ul>
          </div>

          <div class="col-lg-3 col-md-6 footer-links">
            <h4>Sosyal Medya Linklerimiz:</h4>
            <div class="social-links mt-3">
              <a href="<?php echo $ayarcek['twitter']; ?>" class="twitter"><i class="bx bxl-twitter"></i></a>
              <a href="<?php echo $ayarcek['facebook']; ?>" class="facebook"><i class="bx bxl-facebook"></i></a>
              <a href="<?php echo $ayarcek['instagram']; ?>" class="instagram"><i class="bx bxl-instagram"></i></a>
              <a href="<?php echo $ayarcek['skype']; ?>" class="google-plus"><i class="bx bxl-skype"></i></a>
              <a href="<?php echo $ayarcek['linkedin']; ?>" class="linkedin"><i class="bx bxl-linkedin"></i></a>
            </div>
          </div>

        </div>
      </div>
    </div>

    <div class="container py-4">
      <div class="copyright">
        &copy; Copyright <strong><span><?php echo $ayarcek['baslik']; ?> </span></strong>.
      </div>
      <div class="credits">
        <!-- All the links in the footer should remain intact. -->
        <!-- You can delete the links only if you purchased the pro version. -->
        <!-- Licensing information: https://bootstrapmade.com/license/ -->
        <!-- Purchase the pro version with working PHP/AJAX contact form: https://bootstrapmade.com/ninestars-free-bootstrap-3-theme-for-creative/ -->
        Designed by <a href="">OK YAPIM</a>
      </div>
    </div>
  </footer><!-- End Footer -->

  <a href="#" class="back-to-top d-flex align-items-center justify-content-center"><i class="bi bi-arrow-up-short"></i></a>

  <!-- Vendor JS Files -->
  <script src="assets/vendor/aos/aos.js"></script>
  <script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="assets/vendor/glightbox/js/glightbox.min.js"></script>
  <script src="assets/vendor/isotope-layout/isotope.pkgd.min.js"></script>
  <script src="assets/vendor/swiper/swiper-bundle.min.js"></script>
  <script src="assets/vendor/php-email-form/validate.js"></script>
  <script src="//cdn.jsdelivr.net/npm/sweetalert2@11"></script>
  <script src="sweetalert2.all.min.js"></script>
  <!-- Template Main JS File -->
  <script src="assets/js/main.js"></script>
  <script type="text/javascript" src="sweetalert2.all.min.js"></script>

</script>
</body>

</html>