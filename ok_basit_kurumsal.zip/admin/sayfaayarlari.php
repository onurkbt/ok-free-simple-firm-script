<?php include 'header.php'; ?>

<?php
$ayarsor=$db->prepare("SELECT * FROM sayfa_ayarlari");
$ayarsor->execute();
$ayarcek=$ayarsor->fetch(PDO::FETCH_ASSOC);
?>

<main id="main" class="main">
<section class="section">
      <div class="row">
        <div class="col-lg-6">

          <div class="card">
            <div class="card-body">
              <h5 class="card-title">Sayfa Ayarları</h5>

              <!-- General Form Elements -->
              <form action="islemler/islem.php" method="POST">
              <div class="row mb-5">
                <div class="row mb-3">
                  <label for="inputText" class="col-sm-2 col-form-label">Başlık</label>
                  <div class="col-sm-10">
                    <input type="text" class="form-control" name="baslik" value="<?php echo $ayarcek['baslik']; ?>">
                  </div>
                </div>
                <div class="row mb-3">
                  <label for="inputText" class="col-sm-2 col-form-label">Slogan</label>
                  <div class="col-sm-10">
                    <input type="text" class="form-control"name="slogan" value="<?php echo $ayarcek['slogan']; ?>">
                  </div>
                </div>
                <div class="row mb-3">
                  <label for="inputText" class="col-sm-2 col-form-label">Adres</label>
                  <div class="col-sm-10">
                    <input type="text" class="form-control" name="adres" value="<?php echo $ayarcek['adres']; ?>">
                  </div>
                </div>
                <div class="row mb-3">
                  <label for="inputText" class="col-sm-2 col-form-label">Telefon</label>
                  <div class="col-sm-10">
                    <input type="text" class="form-control" name="tel" value="<?php echo $ayarcek['tel']; ?>">
                  </div>
                </div>
                <div class="row mb-3">
                  <label for="inputText" class="col-sm-2 col-form-label">E-Posta</label>
                  <div class="col-sm-10">
                    <input type="text" class="form-control" name="eposta" value="<?php echo $ayarcek['eposta']; ?>">
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div class="col-lg-6">
          <div class="card">
            <div class="card-body">
              <h5 class="card-title">Sosyal Medya Linkleri</h5>      
                <div class="row mb-5">
                <div class="row mb-3">
                  <label for="inputText" class="col-sm-2 col-form-label">Twitter</label>
                  <div class="col-sm-10">
                    <input type="text" class="form-control" name="twitter" value="<?php echo $ayarcek['twitter']; ?>">
                  </div>
                </div>
                <div class="row mb-3">
                  <label for="inputText" class="col-sm-2 col-form-label">Facebook</label>
                  <div class="col-sm-10">
                    <input type="text" class="form-control" name="facebook" value="<?php echo $ayarcek['facebook']; ?>">
                  </div>
                </div>
                <div class="row mb-3">
                  <label for="inputText" class="col-sm-2 col-form-label">Instagram</label>
                  <div class="col-sm-10">
                    <input type="text" class="form-control" name="instagram" value="<?php echo $ayarcek['instagram']; ?>">
                  </div>
                </div>
                <div class="row mb-3">
                  <label for="inputText" class="col-sm-2 col-form-label">Skype</label>
                  <div class="col-sm-10">
                    <input type="text" class="form-control" name="skype" value="<?php echo $ayarcek['skype']; ?>">
                  </div>
                </div>
                <div class="row mb-3">
                  <label for="inputText" class="col-sm-2 col-form-label">Linkedin</label>
                  <div class="col-sm-10">
                    <input type="text" class="form-control" name="linkedin" value="<?php echo $ayarcek['linkedin']; ?>">
                  </div>
                </div>
                </div>
                </div>
                </div>
            </div>
          </div>
        </div>
      </div>
    </section>
    
    <div class="col-lg-12">

          <div class="card">
            <div class="card-body">
              <h5 class="card-title">Harita </h5>
              <p class="col-sm-6 col-form-label text-danger"> <b>Örnek : </b> iframe src="bu kısımda ki bulunan map kodunu yapıştırmalısınız"iframe"></p>
              <div class="row mb-3">
                  <label for="inputText" class="col-sm-2 col-form-label">Harita iframe src: ekle</label>
                  <div class="col-sm-10">
                    <input type="text" class="form-control" name="harita" value="<?php echo $ayarcek['harita'];?>">
                  </div>
                </div>
              <iframe value="<?php echo $ayarcek['harita'];?>"src="<?php echo $ayarcek['harita'];?>" frameborder="0" style="border:0; width: 100%; height: 290px; border-radius:12px;" allowfullscreen=""></iframe>
            </div>
          </div>
    </div>
    <div class="row mb-3">
                  <div class="col-sm-10">
                    <button type="submit" name="genelayarlarkaydet" class="btn btn-primary">Kaydet</button>
                  </div>
                </div>
              </form>
  </main><!-- End #main -->








<?php include 'footer.php'; ?>