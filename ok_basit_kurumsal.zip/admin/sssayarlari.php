<?php include 'header.php'; ?>
<?php

$ssssor=$db->prepare("SELECT * FROM sss_ayarlari");
$ssssor->execute();
$ssscek=$ssssor->fetch(PDO::FETCH_ASSOC);


?>


<main id="main" class="main">
<section class="section">
      <div class="row">
        <div class="col-lg-12">
          <div class="card">
            <div class="card-body">
              <h5 class="card-title">Sıkça Sorulan Sorular Ayarları</h5>
              <form action="islemler/islem.php" method="POST" enctype="multipart/form-data">
              <div class="row mb-5">
                <div class="row mb-3">
                  <label for="inputText" class="col-sm-2 col-form-label">Soru Başlık</label>
                  <div class="col-sm-10">
                    <input type="text" class="form-control" name="sss_soru" value="">
                  </div>
                </div>
                <div class="row mb-3">
                  <label for="inputText" class="col-sm-2 col-form-label">Soru Cevap</label>
                  <div class="col-sm-10">
                    <textarea type="text" class="form-control" name="sss_cevap"></textarea>
                  </div>
                </div>          
            </div>
          </div>
        </div>           
      </div>
    </section> 
    </div>
    <div class="row mb-3">
    <div class="col-sm-10">
    <button type="submit" name="soruekle" class="btn btn-primary">Soru ve Cevap Ekle</button>
    </div>
    </div>
    </form>

    <div class="card">
            <div class="card-body">
              <h5 class="card-title">Sıkça Sorulan Sorular Tablo</h5>

              <!-- Table with hoverable rows -->
              <table class="table table-hover">
                <thead>
                  <tr>
                    
                    <th scope="col">ID</th>
                    <th scope="col">Başlık</th>
                    <th scope="col">Açıklama</th>
                    <th scope="col">Sil</th>
                  </tr>
                </thead>
                <tbody>
                <?php

$ssssor=$db->prepare("SELECT * FROM sss_ayarlari");
$ssssor->execute();
while ($ssscek=$ssssor->fetch(PDO::FETCH_ASSOC)) {

?>



</th>
<tr>
                    <td><?php echo $ssscek['sss_id']?></td>
                    <td><?php echo $ssscek['sss_soru']?></td>
                    <td><?php echo $ssscek['sss_cevap']?></td>
                    <td>
                    <form action="islemler/islem.php" method="POST">
                    <input type="hidden" name="sss_id" value="<?php echo $ssscek['sss_id'] ?>" >
                    <button type="submit" name="ssssil" class="btn btn-danger pl-5"><i class="ri-delete-back-2-fill"></i></button>
                    </form>
                    </td>
                  <?php 
}
?>
                  </tr>
                </tbody>
              </table>
              <!-- End Table with hoverable rows -->

            </div>
          </div>
    </main><!-- End #main -->






<?php include 'footer.php'; ?>