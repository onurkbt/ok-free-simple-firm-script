<?php include 'header.php'; ?>

<?php

$galerisor=$db->prepare("SELECT * FROM galeri_ayarlari");
$galerisor->execute();
$galericek=$galerisor->fetch(PDO::FETCH_ASSOC);


?>


<main id="main" class="main">
<section class="section">
      <div class="row">
        <div class="col-lg-12">
          <div class="card">
            <div class="card-body">
              <h5 class="card-title">Galeri Ayarları</h5>
              <form action="islemler/islem.php" method="POST" enctype="multipart/form-data">
              <div class="row mb-5">
              <div class="row mb-3">
                  <label for="inputNumber" class="col-sm-2 col-form-label">Galeri Resim Yükle <b>(jpeg)</b></label>
                  <div class="col-sm-10">
                   <input class="form-control"type="file" name="galeri_resim"/><br/>
                </div>    
                </div>
            </div>
          </div>
        </div>           
      </div>
    </section> 
    </div>
    <div class="row mb-3">
    <div class="col-sm-10">
    <button type="submit" name="galeriekle" class="btn btn-primary">Ekle</button>

    </div>
    </div>
    </form>

    <div class="card">
            <div class="card-body">
              <h5 class="card-title">Galeri Resim Tablo</h5>

              <!-- Table with hoverable rows -->
              <table class="table table-hover">
                <thead>
                  <tr>
                    <th scope="col">ID</th>
                    <th scope="col">Başlık</th>
                    <th scope="col">Sil</th>
                  </tr>
                </thead>
                <tbody>
             <?php 

$galerisor=$db->prepare("SELECT * FROM galeri_ayarlari");
$galerisor->execute();
while ($galericek=$galerisor->fetch(PDO::FETCH_ASSOC)) {


?>
                  <tr>  
                    </th>
                    <th><?php echo $galericek['galeri_id'];?></th>
                    <td><?php echo $galericek['galeri_resim'];?></td>
                    <td>
                    <form action="islemler/islem.php" method="POST">
                    <input type="hidden" name="galeri_id" value="<?php echo $galericek['galeri_id'] ?>" >
                    <button type="submit" name="galerisil" class="btn btn-danger pl-5"><i class="ri-delete-back-2-fill"></i></button>
                    </form>
                    </td>
                  <?php 
}
?>
                  </tr>
                </tbody>
              </table>
              <!-- End Table with hoverable rows -->

            </div>
          </div>
    </main><!-- End #main -->
<?php include 'footer.php'; ?>