<?php  include 'header.php';  ?>


  <main id="main" class="main">

    <div class="pagetitle">
      <h1></h1>
    </div><!-- End Page Title -->

    <section class="section dashboard">
      <div class="row" style="--bs-gutter-x: 1.5rem;
    --bs-gutter-y: 0;
    display: flex;
    flex-wrap: nowrap;
    margin-top: calc(-1 * var(--bs-gutter-y));
    margin-right: calc(-.5 * var(--bs-gutter-x));
    margin-left: calc(-.5 * var(--bs-gutter-x));
    justify-content: center;
" > 

        <!-- Left side columns -->
        <div class="col-lg-8">
          <div class="row">

            <!-- Sales Card -->
            <div class="col-xxl-4 col-md-6">
              <div class="card info-card sales-card">
                <div class="card-body">
                  <h5 class="card-title">IP Adresi <span>| Log</span></h5>

                  <div class="d-flex align-items-center">
                    <div class="card-icon rounded-circle d-flex align-items-center justify-content-center">
                      <i class="ri-computer-line"></i>
                    </div>
                    <?php $_SERVER["REMOTE_ADDR"];?>
                    <div class="ps-3">
                      <h6><?php echo $_SERVER["REMOTE_ADDR"];?></h6>
                     

                    </div>
                  </div>
                </div>

              </div>
            </div><!-- End Sales Card -->

            <!-- Revenue Card -->
            <div class="col-xxl-4 col-md-6">
              <div class="card info-card customers-card">    
                <div class="card-body">
                  <h5 class="card-title">Galeri <span>| Toplam Resim</span></h5>

                  <div class="d-flex align-items-center">
                  <div class="card-icon rounded-circle d-flex align-items-center justify-content-center">
                      <i class="ri-gallery-fill"></i>
                    </div>
                    <?php
                    $galerisor=$db->prepare("SELECT COUNT(*) FROM galeri_ayarlari");
                    $galerisor->execute();
                    $galericek= $galerisor->fetchColumn();
                    ?>
                    <div class="ps-3">
                      <h6><?php echo $galericek;?></h6>
                    </div>
                  </div>
                </div>

              </div>
            </div><!-- End Revenue Card -->

            <div class="col-xxl-4 col-md-6">
              <div class="card info-card revenue-card">    
                <div class="card-body">
                  <h5 class="card-title">Hizmetler <span>| Toplam</span></h5>

                  <div class="d-flex align-items-center">
                    <div class="card-icon rounded-circle d-flex align-items-center justify-content-center">
                      <i class="ri-file-list-3-fill"></i>
                    </div>
                    <?php
                    $hizmetsor=$db->prepare("SELECT COUNT(*) FROM hizmet_ayarlari");
                    $hizmetsor->execute();
                    $hizmetcek= $hizmetsor->fetchColumn();
                    ?>
                    <div class="ps-3">
                      <h6><?php echo $hizmetcek;?></h6>
                    </div>
                  </div>
                </div>

              </div>
            </div><!-- End Revenue Card -->
           
           
            <!-- End Customers Card -->

          </div>
        </div>
      </div> 
      </div>
    </section>
</div>

 <!-- Recent Sales -->
 <div class="col-12">
              <div class="card recent-sales overflow-auto">
                <div class="card-body">
                  <h5 class="card-title">Gelen <span>| Mesajlar</span></h5>
                  
                  <table class="table table" id="myTable">
                    
                    <thead>
                      <tr>
                        <th>ID</th>
                        <th>Gönderenin Mail Adresi:</th>
                        <th>Konusu:</th>
                        <th>Mesajı:</th>
                        <th scope="col">Sil</th>
                      </tr>
                    </thead>
                    <tbody>
                   
                    <?php 
$mesajsor=$db->prepare("SELECT * FROM mesajlar LIMIT 25");
$mesajsor->execute();

while ($mesajcek=$mesajsor->fetch(PDO::FETCH_ASSOC)) {

?>
                      <tr id="myFunction">
                        <td><?php echo $mesajcek['mesajlar_id']?></td>
                        <td><?php echo $mesajcek['mesajlar_mail']?></td>
                        <td><?php echo $mesajcek['mesajlar_konu']?></td>
                        <td><?php echo $mesajcek['mesajlar_mesaj']?></td>
                        <td>
                    <form action="islemler/islem.php" method="POST">
                    <input type="hidden" name="mesajlar_id" value="<?php echo $mesajcek['mesajlar_id'] ?>" >
                   <a><button type="submit" name="mesajsilme" href="islemler/islem.php"  onclick="return confirmDelete(this)" class="btn btn-danger pl-5"><i class="ri-delete-back-2-fill"></i></button></a> 
                 
                    </td>
                      </tr>
                      <?php }?>
                    </tbody>
                  </table>
                </div>
              </div>
            </div><!-- End Recent Sales -->

</main><!-- End #main -->

<script>
function myFunction() {
  // Declare variables
  var input, filter, table, tr, td, i, txtValue;
  input = document.getElementById("myInput");
  filter = input.value.toUpperCase();
  table = document.getElementById("myTable");
  tr = table.getElementsByTagName("tr");

  // Loop through all table rows, and hide those who don't match the search query
  for (i = 1; i < tr.length; i++) {
  td = tr[i];
  if (td) {
    txtValue = td.textContent || td.innerText;
    if (txtValue.toUpperCase().indexOf(filter) > -1) {
      tr[i].style.display = "";
    } else {
      tr[i].style.display = "none";
    }
  }
}
}
</script>

 <?php include 'footer.php'; ?>

<script>

function sil(mesajlar_id){
  Swal.fire({
  title: 'Mesajı Silmek İstediğine Emin Misiniz ?',
  text: "Bu işlem geri alınamaz.",
  icon: 'warning',
  showCancelButton: true,
  confirmButtonColor: '#3085d6',
  cancelButtonColor: '#d33',
  cancelButtonText: 'Hayır!',
  confirmButtonText: 'Evet, sil'
}).then((result)  => {
  if (result.isConfirmed) {
    window.location.href = 'islemler/islem.php'
    Swal.fire(
      'Silindi',
      'Your file has been deleted.',
      'success'
    )
  }
})

}



</script>