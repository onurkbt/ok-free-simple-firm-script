<?php include 'header.php'; ?>

<?php

$hizmetsor=$db->prepare("SELECT * FROM hizmet_ayarlari");
$hizmetsor->execute();
$hizmetcek=$hizmetsor->fetch(PDO::FETCH_ASSOC);


?>


<main id="main" class="main">
<section class="section">
      <div class="row">
        <div class="col-lg-12">
          <div class="card">
            <div class="card-body">
              <h5 class="card-title">Hizmet Ayarları</h5>
              <form action="islemler/islem.php" method="POST" enctype="multipart/form-data">
              <div class="row mb-5">
                <div class="row mb-3">
                  <label for="inputText" class="col-sm-2 col-form-label">Hizmet Başlık</label>
                  <div class="col-sm-10">
                    <input type="text" class="form-control" name="hizmet_baslik" value="">
                  </div>
                </div>
                <div class="row mb-3">
                  <label for="inputText" class="col-sm-2 col-form-label">Hizmet Açıklama</label>
                  <div class="col-sm-10">
                    <textarea type="text" class="form-control" name="hizmet_aciklama"></textarea>
                  </div>
                </div>          
            </div>
          </div>
        </div>           
      </div>
    </section> 
    </div>
    <div class="row mb-3">
    <div class="col-sm-10">
    <button type="submit" name="hizmetekle" class="btn btn-primary">Ekle</button>

    </div>
    </div>
    </form>

    <div class="card">
            <div class="card-body">
              <h5 class="card-title">Hizmetler Tablo</h5>

              <!-- Table with hoverable rows -->
              <table class="table table-hover">
                <thead>
                  <tr>
                    <th scope="col">Düzenle</th>
                    <th scope="col">ID</th>
                    <th scope="col">Başlık</th>
                    <th scope="col">Açıklama</th>
                    <th scope="col">Sil</th>
                  </tr>
                </thead>
                <tbody>
                <?php

$hizmetsor=$db->prepare("SELECT * FROM hizmet_ayarlari");
$hizmetsor->execute();
while ($hizmetcek=$hizmetsor->fetch(PDO::FETCH_ASSOC)) {


?>
                  <tr>
                    <th>
                    <form action="hizmetduzenle.php" method="POST">
                    <input type="hidden" name="hizmet_id" value="<?php echo $hizmetcek['hizmet_id'] ?>" >
                    <button type="submit" name="hizmetduzenleme" class="btn btn-primary pl-5"><i class="ri-eye-fill"></i></button>
                   </form>
                        
                    </th>
                    <th><?php echo $hizmetcek['hizmet_id'];?></th>
                    <td><?php echo $hizmetcek['hizmet_baslik'];?></td>
                    <td><?php echo $hizmetcek['hizmet_aciklama'];?></td>
                    <td>
                    <form action="islemler/islem.php" method="POST">
                    <input type="hidden" name="hizmet_id" value="<?php echo $hizmetcek['hizmet_id'] ?>" >
                    <button type="submit" name="hizmetsilme" class="btn btn-danger pl-5"><i class="ri-delete-back-2-fill"></i></button>
                    </form>
                    </td>
                  <?php 
}
?>
                  </tr>
                </tbody>
              </table>
              <!-- End Table with hoverable rows -->

            </div>
          </div>
    </main><!-- End #main -->

















<?php include 'footer.php'; ?>