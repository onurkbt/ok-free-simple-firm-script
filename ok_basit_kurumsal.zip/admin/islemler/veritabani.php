<?php 

$db_name = 'ok_basit_kurumsal';
$hosting = 'localhost';
$kul_adi = 'root';
$kul_sfr = '';

try {
    $db = new PDO("mysql:host=$hosting;dbname=$db_name;charset=utf8;", $kul_adi, $kul_sfr);
    // set the PDO error mode to exception
    $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
   // echo "basarili";
  } catch(PDOException $e) {
    echo "hata " . $e->getMessage();
  }

?>