<?php include 'veritabani.php'; ?>
<?php

    $adminsor=$db->prepare("SELECT*FROM admin_ayarlari WHERE admin_kullanici_adi=:adi");
    $adminsor->execute(array(
        'adi'=> $_SESSION['admin_kullanici_adi']
    ));

ob_start();

unset($_SESSION['admin_kullanici_adi']);
session_start();
session_destroy();
header("location:../giris.php?cikisbasarili");
exit;
?>

<?php include 'veritabani.php'; ?>