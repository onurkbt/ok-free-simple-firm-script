<?php include 'veritabani.php'; ?>
<?php

ob_start();
session_start();

if(isset($_POST['genelayarlarkaydet'])) 
{
     $genelayarlarkaydet =$db ->prepare("UPDATE sayfa_ayarlari SET 
     baslik   =:baslik,
     slogan   =:slogan,
     adres    =:adres,
     tel      =:tel,
     eposta   =:eposta,
     instagram =:instagram,
     twitter  =:twitter,
     facebook=:facebook,
     skype=:skype,
     linkedin=:linkedin,
     harita =:harita

    ");
    $genelayarlarkaydet -> execute
    (array(
    'baslik'   => $_POST['baslik'],
    'slogan'   => $_POST['slogan'],
    'adres'   => $_POST['adres'],
    'tel'   => $_POST['tel'],
    'eposta'   => $_POST['eposta'],
    'instagram'   => $_POST['instagram'],
    'twitter'   => $_POST['twitter'],
    'facebook'   => $_POST['facebook'],
    'skype'  => $_POST['skype'],
    'linkedin'   => $_POST['linkedin'],
    'harita'   => $_POST['harita']
 

    ));
    header('Refresh: 0.3; url=../sayfaayarlari.php');
}

if(isset($_POST['sliderayarkaydet'])) 
{

    
    $genelayarlarkaydet =$db->prepare("UPDATE slider_ayarlari SET 
     slider_baslik   =:slider_baslik ,
     slider_aciklama   =:slider_aciklama


    ");
    $genelayarlarkaydet -> execute
    (array(
   'slider_baslik' => $_POST['slider_baslik'],
   'slider_aciklama' => $_POST['slider_aciklama']
   
   
   
    ));
 
   {
 
        if ($_FILES["slider_resim"]["size"]<1024*1024){//Dosya boyutu  aldık ve 1Mb'tan az olmasını söyledik.
     
            if ($_FILES["slider_resim"]["type"]=="image/png"){  //Dosya tipi aldık ve sadece jpeg olmasını söyledik.
     
                $dosya_adi  =  $_FILES["slider_resim"]["name"];  //Dsoya adını aldık.
     
                //Resimi kayıt ederken yeni bir isim oluşturalım
                $uret=array("cv","fg","th","lu","er");
                $uzanti=substr($dosya_adi,-4,4);
                $sayi_tut=rand(1,10000);
     
                $slider_resim="resimler/".$uret[rand(0,4)].$sayi_tut.$uzanti;
     
                //Dosya yeni adıyla resimler klasörüne kaydedilecek
     
                if (move_uploaded_file($_FILES["slider_resim"]["tmp_name"],$slider_resim)){
     
                    //Bilgileri veritabanına kayıt ediyoruz..
     
                    $sliderayarkaydet = $db->prepare("UPDATE slider_ayarlari SET slider_resim=:slider_resim");
                    $sliderayarkaydet->execute(array(':slider_resim'=> $slider_resim));
                    
            }
        }
      }
    }
    header('Refresh: 0.1; url=../sliderayarlari.php');
   
   
   
}


if(isset($_POST['hakkimizdaayarlarikaydet'])) 
{

    
    $genelayarlarkaydet =$db->prepare("UPDATE hakkimizda_ayarlari SET 
     hakkimizda_baslik=:hakkimizda_baslik,
     hakkimizda_aciklama=:hakkimizda_aciklama
    ");
    $genelayarlarkaydet -> execute
    (array(
   'hakkimizda_baslik' => $_POST['hakkimizda_baslik'],
   'hakkimizda_aciklama' => $_POST['hakkimizda_aciklama']
    ));
   
    {
 
        if ($_FILES["hakkimizda_resim"]["size"]<1024*1024){//Dosya boyutu  aldık ve 1Mb'tan az olmasını söyledik.
     
            if ($_FILES["hakkimizda_resim"]["type"]=="image/png"){  //Dosya tipi aldık ve sadece jpeg olmasını söyledik.
     
                $dosya_adi   =  $_FILES["hakkimizda_resim"]["name"];  //Dsoya adını aldık.
     
                //Resimi kayıt ederken yeni bir isim oluşturalım
                $uret=array("cv","fg","th","lu","er");
                $uzanti=substr($dosya_adi,-4,4);
                $sayi_tut=rand(1,10000);
     
                $hakkimizda_resim="resimler/".$uret[rand(0,4)].$sayi_tut.$uzanti;
     
                //Dosya yeni adıyla resimler klasörüne kaydedilecek
     
                if (move_uploaded_file($_FILES["hakkimizda_resim"]["tmp_name"],$hakkimizda_resim)){
     
                    //Bilgileri veritabanına kayıt ediyoruz..
     
                    $hakkimizdaayarlarikaydet = $db->prepare("UPDATE hakkimizda_ayarlari SET hakkimizda_resim=:hakkimizda_resim");
                    $hakkimizdaayarlarikaydet->execute(array(':hakkimizda_resim'=> $hakkimizda_resim));
                    
            }
        }
      }
    }
    header('Refresh: 0.5; url=../hakkimizdaayarlari.php');
}

if(isset($_POST['hizmetekle'])) 
{

    
    $hizmetekle =$db->prepare("INSERT INTO hizmet_ayarlari SET 
     hizmet_baslik=:hizmet_baslik,
     hizmet_aciklama=:hizmet_aciklama
    ");
    $hizmetekle -> execute
    (array(
   'hizmet_baslik' => $_POST['hizmet_baslik'],
   'hizmet_aciklama' => $_POST['hizmet_aciklama']
    ));
    header('Refresh: 0.1; url=../hizmetayarlari.php');
}



if(isset($_POST['hizmetsilme'])){

$sil=$db->prepare("DELETE FROM hizmet_ayarlari WHERE hizmet_id=:hizmet_id");
$kontrol=$sil->execute(array(
    'hizmet_id' => $_POST['hizmet_id']
));
header('Refresh: 0.1; url=../hizmetayarlari.php');

}
if(isset($_POST['hizmetguncelle'])) 
{

    
    $hizmetguncelle =$db->prepare("UPDATE hizmet_ayarlari SET 
     hizmet_baslik=:hizmet_baslik,
     hizmet_aciklama=:hizmet_aciklama 
     WHERE hizmet_id=:hizmet_id

    ");
    $hizmetguncelle -> execute
    (array(
   'hizmet_baslik' => $_POST['hizmet_baslik'],
   'hizmet_aciklama' => $_POST['hizmet_aciklama'],
   'hizmet_id' => $_POST['hizmet_id']

    ));
  header('Refresh: 0.1; url=../hizmetayarlari.php');
}

if(isset($_POST['galeriekle'])) 
{
    if ($_FILES["galeri_resim"]["size"]<9024*9024){//Dosya boyutu  aldık ve 1Mb'tan az olmasını söyledik.
     
        if ($_FILES["galeri_resim"]["type"]=="image/jpeg"){  //Dosya tipi aldık ve sadece jpeg olmasını söyledik.
 
            $dosya_adi   =  $_FILES["galeri_resim"]["name"];  //Dsoya adını aldık.
 
            //Resimi kayıt ederken yeni bir isim oluşturalım
            $uret=array("cv","fg","th","lu","er");
            $uzanti=substr($dosya_adi,-4,4);
            $sayi_tut=rand(1,10000);
 
            $galeri_resim="resimler/".$uret[rand(0,4)].$sayi_tut.$uzanti;
 
            //Dosya yeni adıyla resimler klasörüne kaydedilecek
 
            if (move_uploaded_file($_FILES["galeri_resim"]["tmp_name"],$galeri_resim)){
 
                //Bilgileri veritabanına kayıt ediyoruz..
 
                $galeri_resimkaydet = $db->prepare("INSERT INTO galeri_ayarlari SET galeri_resim=:galeri_resim");
                $galeri_resimkaydet->execute(array(':galeri_resim'=> $galeri_resim));
                
        }
    }
  }
  header('Refresh: 0.1; url=../galeriayarlari.php');
}
if(isset($_POST['galerisil'])){

    $sil=$db->prepare("DELETE FROM galeri_ayarlari WHERE galeri_id=:galeri_id");
    $kontrol=$sil->execute(array(
        'galeri_id' => $_POST['galeri_id']
    ));
    header('Refresh: 0.1; url=../galeriayarlari.php');
    
}

if(isset($_POST['soruekle'])) {

$soruekle=$db->prepare("INSERT INTO sss_ayarlari SET 
sss_soru=:sss_soru,
sss_cevap=:sss_cevap
");
$soruekle -> execute(array(
'sss_soru' => $_POST['sss_soru'],
'sss_cevap' => $_POST['sss_cevap']

));
header('Refresh: 0.1; url=../sssayarlari.php');

}

if(isset($_POST['ssssil'])){

$silgitsin = $db->prepare("DELETE FROM sss_ayarlari WHERE sss_id=:sss_id");
$silgitsin->execute(array(
'sss_id' => $_POST['sss_id']
));

header('Refresh: 0.1; url=../sssayarlari.php');

}


if(isset($_POST['refekle'])) 
{
    if ($_FILES["referans_logo"]["size"]<9024*9024){//Dosya boyutu  aldık ve 1Mb'tan az olmasını söyledik.
     
        if ($_FILES["referans_logo"]["type"]=="image/png"){  //Dosya tipi aldık ve sadece jpeg olmasını söyledik.
 
            $dosya_adi   =  $_FILES["referans_logo"]["name"];  //Dsoya adını aldık.
 
            //Resimi kayıt ederken yeni bir isim oluşturalım
            $uret=array("cv","fg","th","lu","er");
            $uzanti=substr($dosya_adi,-4,4);
            $sayi_tut=rand(1,10000);
 
            $referans_logo="resimler/".$uret[rand(0,4)].$sayi_tut.$uzanti;
 
            //Dosya yeni adıyla resimler klasörüne kaydedilecek
 
            if (move_uploaded_file($_FILES["referans_logo"]["tmp_name"],$referans_logo)){
 
                //Bilgileri veritabanına kayıt ediyoruz..
 
                $referans_logokaydet = $db->prepare("INSERT INTO referans_ayarlari SET referans_logo=:referans_logo");
                $referans_logokaydet->execute(array(':referans_logo'=> $referans_logo));
                
        }
    }
  }
  header('Refresh: 0.1; url=../referansayarlari.php');
}
if(isset($_POST['refsil'])){

    $refisil=$db->prepare("DELETE FROM referans_ayarlari WHERE referans_id=:referans_id");
    $refisil->execute(array(
        'referans_id' => $_POST['referans_id']
    ));
header('Refresh: 0.2; url=../referansayarlari.php');

}

if(isset($_POST['oturumac']))
{
$adminsor=$db->prepare("SELECT*FROM admin_ayarlari WHERE admin_kullanici_adi=:adi AND admin_kullanici_sifresi=:sifre");
$adminsor->execute(array(
    'adi'=> $_POST['admin_kullanici_adi'],
    'sifre'=> $_POST['admin_kullanici_sifresi']
));
$sonuc=$adminsor->rowcount();
if($sonuc==0){
   header("location:../giris.php");
}else {
    $_SESSION['admin_kullanici_adi']=$_POST['admin_kullanici_adi'];
    header("location:../index.php");
}
}


if(isset($_POST['profilguncelleme'])){
  


  $profilguncelle=$db->prepare("UPDATE admin_ayarlari SET admin_adi=:isim, admin_kullanici_adi=:adi,admin_kullanici_sifresi=:sifresi");
  $profilguncelle->execute(array(
  'isim' => $_POST['admin_adi'],
  'adi' =>  $_POST['admin_kullanici_adi'], 
  'sifresi' => $_POST['admin_kullanici_sifresi']
  

  ));
header("Refresh:0.1; url=../giris.php");
}

if(isset($_POST['mesajgonder'])) {
    $mesajsor=$db->prepare("INSERT INTO mesajlar SET 
    mesajlar_isim=:isim,
    mesajlar_mail=:mail,
    mesajlar_konu=:konu,
    mesajlar_mesaj=:mesaj
    ");
    $mesajsor->execute(array(
        'isim' => $_POST['mesajlar_isim'],
        'mail' => $_POST['mesajlar_mail'],
        'konu' => $_POST['mesajlar_konu'],
        'mesaj' => $_POST['mesajlar_mesaj']
        
    
        
    ));
    
    header('location:../../index.php');
    }
  




if(isset($_POST['mesajsilme'])){

    $sil=$db->prepare("DELETE FROM mesajlar WHERE mesajlar_id=:mesajlar_id");
    $kontrol=$sil->execute(array(
        'mesajlar_id' => $_POST['mesajlar_id']
    ));
 
    header('Refresh:0.5;url=../index.php');
}
   
?>

