<?php include 'header.php'; ?>

<?php
$slidersor=$db->prepare("SELECT * FROM slider_ayarlari");
$slidersor->execute();
$slidercek=$slidersor->fetch(PDO::FETCH_ASSOC);
?>

<main id="main" class="main">
<section class="section">
      <div class="row">
        <div class="col-lg-12">
          <div class="card">
            <div class="card-body">
              <h5 class="card-title">Slider Ayarları</h5>
              <form action="islemler/islem.php" method="POST" enctype="multipart/form-data">
              <div class="row mb-5">
                <div class="row mb-3">
                  <label for="inputText" class="col-sm-2 col-form-label">Slider Başlık</label>
                  <div class="col-sm-10">
                    <input type="text" class="form-control" name="slider_baslik" value="<?php echo $slidercek['slider_baslik']; ?>">
                  </div>
                </div>
                <div class="row mb-3">
                  <label for="inputText" class="col-sm-2 col-form-label">Slider Açıklama</label>
                  <div class="col-sm-10">
                    <input type="text" class="form-control"name="slider_aciklama" value="<?php echo $slidercek['slider_aciklama']; ?>">
                  </div>
                </div>          
            <!-- resim yükleme kısmı -->
                <div class="row mb-3">
                  <label for="inputNumber" class="col-sm-2 col-form-label">Slider Resim Yükle <b>( png )</b></label>
                  <div class="col-sm-10">
                   <input class="form-control"type="file" name="slider_resim"/><br/>
                </div>    
                </div>
              </div> 
            </div>
          </div>
        </div>           
      </div>
    </section> 
    <div class="col-lg-12">
          <div class="card">
            <div class="card-body">
              <h5 class="card-title">Slider Görsel</h5>
              <div id="carouselExampleSlidesOnly" class="carousel slide" data-bs-ride="carousel">
                <div class="carousel-inner">
                  <div class="carousel-item active">
                  <?php 
        $slidercek=$db->prepare("SELECT * FROM slider_ayarlari");
        $slidercek->execute();
        if($slidercek->rowCount()){ 
          foreach($slidercek as $row){ 
        ?>   
        <img src="islemler/<?php echo $row['slider_resim']; ?>" alt="" class="img-fluid animated" width="500" height="300">  
        <?php
        }
        ?>
        <?php
        }
        ?>
        
    </div>
    </div>
    </div>
    </div>
    </div>
    <div class="row mb-3">
    <div class="col-sm-10">
    <button type="submit" name="sliderayarkaydet" class="btn btn-primary">Kaydet</button>
    </div>
    </div>
    </form>
    </main><!-- End #main -->




  
<?php include 'footer.php'; ?>