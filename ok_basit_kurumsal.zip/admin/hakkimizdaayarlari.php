<?php include 'header.php'; ?>

<?php
$hakkimizdasor=$db->prepare("SELECT * FROM hakkimizda_ayarlari");
$hakkimizdasor->execute();
$hakkimizdacek=$hakkimizdasor->fetch(PDO::FETCH_ASSOC);
?>

<main id="main" class="main">
<section class="section">
      <div class="row">
        <div class="col-lg-12">
          <div class="card">
            <div class="card-body">
              <h5 class="card-title">Hakkımızda Ayarları</h5>
              <form action="islemler/islem.php" method="POST" enctype="multipart/form-data">
              <div class="row mb-5">
                <div class="row mb-3">
                  <label for="inputText" class="col-sm-2 col-form-label">Hakkımızda Başlık</label>
                  <div class="col-sm-10">
                    <input type="text" class="form-control" name="hakkimizda_baslik" value="<?php echo $hakkimizdacek['hakkimizda_baslik']; ?>">
                  </div>
                </div>
                <div class="row mb-3">
                  <label for="inputText" class="col-sm-2 col-form-label">Hakkımızda Açıklama</label>
                  <div class="col-sm-10">
                    <textarea type="text" class="form-control" name="hakkimizda_aciklama"><?php echo $hakkimizdacek['hakkimizda_aciklama']; ?></textarea>
                  </div>
                </div>          
            <!-- resim yükleme kısmı -->
                <div class="row mb-3">
                  <label for="inputNumber" class="col-sm-2 col-form-label">Hakkımızda Resim Yükle <b>(png)</b></label>
                  <div class="col-sm-10">
                   <input class="form-control"type="file" name="hakkimizda_resim"/><br/>
                </div>    
                </div>
              </div> 
            </div>
          </div>
        </div>           
      </div>
    </section> 
    <div class="col-lg-12">
          <div class="card">
            <div class="card-body">
              <h5 class="card-title">Slider Görsel</h5>
              <div id="carouselExampleSlidesOnly" class="carousel slide" data-bs-ride="carousel">
                <div class="carousel-inner">
                  <div class="carousel-item active">
                  <?php 
        $hakkimizdacek=$db->prepare("SELECT * FROM hakkimizda_ayarlari");
        $hakkimizdacek->execute();
        if($hakkimizdacek->rowCount()){ 
          foreach($hakkimizdacek as $row){ 
        ?>   
        <img src="islemler/<?php echo $row['hakkimizda_resim']; ?>" alt="" class="img-fluid animated" width="500" height="300">  
        <?php
        }
        ?>
        <?php
        }
        ?>
        
    </div>
    </div>
    </div>
    </div>
    </div>
    <div class="row mb-3">
    <div class="col-sm-10">
    <button type="submit"  name="hakkimizdaayarlarikaydet" class="btn btn-primary">Kaydet</button>
    </div>
    </div>
    </form>
    </main><!-- End #main -->




  
<?php include 'footer.php'; ?>

