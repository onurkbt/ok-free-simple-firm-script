<?php include 'header.php'; ?>

<?php 
$referanssor=$db->prepare("SELECT * FROM referans_ayarlari");
$referanssor->execute();
$referanscek=$referanssor->fetch(PDO::FETCH_ASSOC);
?>

<main id="main" class="main">
<section class="section">
      <div class="row">
        <div class="col-lg-12">
          <div class="card">
            <div class="card-body">
              <h5 class="card-title">Referans Ayarları</h5>
              <form action="islemler/islem.php" method="POST" enctype="multipart/form-data">
              <div class="row mb-5">
              <div class="row mb-3">
                  <label for="inputNumber" class="col-sm-2 col-form-label">Referans Resim Yükle <b>(png)</b></label>
                  <div class="col-sm-10">
                   <input class="form-control"type="file" name="referans_logo"/><br/>
                </div>    
                </div>
            </div>
          </div>
        </div>           
      </div>
    </section> 
    </div>
    <div class="row mb-3">
    <div class="col-sm-10">
    <button type="submit" name="refekle" class="btn btn-primary">Referans Ekle</button>

    </div>
    </div>
    </form>

    <div class="card">
            <div class="card-body">
              <h5 class="card-title">Referans Logo PNG</h5>

              <!-- Table with hoverable rows -->
              <table class="table table-hover">
                <thead>
                  <tr>
                    <th scope="col">ID</th>
                    <th scope="col">Başlık</th>
                    <th scope="col">Sil</th>
                  </tr>
                </thead>
                <tbody>
             <?php 

$referanssor=$db->prepare("SELECT * FROM referans_ayarlari");
$referanssor->execute();
while ($referanscek=$referanssor->fetch(PDO::FETCH_ASSOC)) {


?>
                  <tr>  
                    </th>
                    <th><?php echo $referanscek['referans_id'];?></th>
                    <td><?php echo $referanscek['referans_logo'];?></td>
                    <td>
                    <form action="islemler/islem.php" method="POST">
                    <input type="hidden" name="referans_id" value="<?php echo $referanscek['referans_id'] ?>" >
                    <button type="submit" name="refsil" class="btn btn-danger pl-5"><i class="ri-delete-back-2-fill"></i></button>
                    </form>
                    </td>
                  <?php 
}
?>
                  </tr>
                </tbody>
              </table>
              <!-- End Table with hoverable rows -->

            </div>
          </div>
    </main><!-- End #main -->
























<?php include 'footer.php'; ?>