<?php include 'header.php'; ?>
<?php

ob_start();
session_start();

if(isset($_POST['hizmet_id']))
$hizmetsor=$db->prepare("SELECT * FROM hizmet_ayarlari WHERE hizmet_id=:hizmet_id");
$hizmetsor->execute(array(
  'hizmet_id' => $_POST['hizmet_id']
));
$hizmetcek=$hizmetsor->fetch(PDO::FETCH_ASSOC);
  

?>
<main id="main" class="main">
<section class="section">
      <div class="row">
        <div class="col-lg-12">
          <div class="card">
          <form action="islemler/islem.php" method="POST" enctype="multipart/form-data">
            <div class="card-body">
              <h5 class="card-title">Hizmet Ayarları <b>( <?php echo $hizmetcek['hizmet_id'] ?> ) </b></h5>
              
              <div class="row mb-5">
                <div class="row mb-3">
                  <label for="inputText" class="col-sm-2 col-form-label">Hizmet Başlık</label>
                  <div class="col-sm-10">
                    <input type="text" class="form-control" name="hizmet_baslik" value="<?php echo $hizmetcek['hizmet_baslik'] ?>">
                  </div>
                </div>
                <div class="row mb-3">
                  <label for="inputText" class="col-sm-2 col-form-label">Hizmet Açıklama</label>
                  <div class="col-sm-10">
                    <textarea type="text" class="form-control" name="hizmet_aciklama"><?php echo $hizmetcek['hizmet_aciklama'] ?></textarea>
                  </div>
                </div>          
            </div>
          </div>
        </div>           
      </div>
    </section> 
    </div>
    <input type="hidden" name="hizmet_id" value="<?php echo $_POST['hizmet_id'] ?>">
    <div class="row mb-3">
    <div class="col-sm-10">
    <button type="submit" name="hizmetguncelle" class="btn btn-primary">Güncelle</button>
    </div>
    </div>
</form>
<?php
include 'footer.php';
?>