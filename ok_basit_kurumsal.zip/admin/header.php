<?php include 'islemler/veritabani.php'; ?>
<?php
$ayarsor=$db->prepare("SELECT * FROM sayfa_ayarlari");
$ayarsor->execute();
$ayarcek=$ayarsor->fetch(PDO::FETCH_ASSOC);

ob_start();
session_start();

if(empty($_SESSION['admin_kullanici_adi'])){
  header("location:giris.php");
}else {
$adminsor=$db->prepare("SELECT*FROM admin_ayarlari WHERE admin_kullanici_adi=:adi");
$adminsor->execute(array(
    'adi'=> $_SESSION['admin_kullanici_adi'],
));
$sonuc=$adminsor->rowcount();
if($sonuc==0){
   header("location:giris.php");
}
}

?>

<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title>OK | Admin Panel</title>
  <meta content="" name="description">
  <meta content="" name="keywords">

  <!-- Favicons -->
  <link href="assets/img/favicon.png" rel="icon">
  <link href="assets/img/apple-touch-icon.png" rel="apple-touch-icon">

  <!-- Google Fonts -->
  <link href="https://fonts.gstatic.com" rel="preconnect">
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Nunito:300,300i,400,400i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">

  <!-- Vendor CSS Files -->
  <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
  <link href="assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
  <link href="assets/vendor/quill/quill.snow.css" rel="stylesheet">
  <link href="assets/vendor/quill/quill.bubble.css" rel="stylesheet">
  <link href="assets/vendor/remixicon/remixicon.css" rel="stylesheet">
  <link href="assets/vendor/simple-datatables/style.css" rel="stylesheet">

  <!-- Template Main CSS File -->
  <link href="assets/css/style.css" rel="stylesheet">

  <!-- =======================================================
  * Template Name: NiceAdmin - v2.4.0
  * Template URL: https://bootstrapmade.com/nice-admin-bootstrap-admin-html-template/
  * Author: BootstrapMade.com
  * License: https://bootstrapmade.com/license/
  ======================================================== -->
</head>

<body>

  <!-- ======= Header ======= -->
  <header id="header" class="header fixed-top d-flex align-items-center">

    <div class="d-flex align-items-center justify-content-between">
      <a href="index.php" class="logo d-flex align-items-center">
       
        <span class="d-none d-lg-block"><?php echo $ayarcek['baslik']; ?></span>
      </a>
      <i class="bi bi-list toggle-sidebar-btn"></i>
    </div><!-- End Logo -->

    <div class="search-bar">
      <form  class="search-form d-flex align-items-center" method="POST" action="#">
      <input type="text" id="myInput" onkeyup="myFunction()" placeholder="Tablo'da mesaj ara...">
        <button type="submit" title="Search"><i class="bi bi-search"></i></button>
      </form>
    </div><!-- End Search Bar -->

    <nav class="header-nav ms-auto">
      <ul class="d-flex align-items-center">

        <li class="nav-item d-block d-lg-none">
          <a class="nav-link nav-icon search-bar-toggle " href="#">
            <i class="bi bi-search"></i>
          </a>
        </li><!-- End Search Icon-->

        

        <li class="nav-item dropdown">
        <?php 
$mesajsor=$db->prepare("SELECT COUNT(*) FROM  mesajlar");
$mesajsor->execute();
$mesajcek=$mesajsor->fetchColumn();

?>
          <a class="nav-link nav-icon" href="#" data-bs-toggle="dropdown">
            <i class="bi bi-chat-left-text"></i>
            <span class="badge bg-success badge-number"><?php echo $mesajcek; ?></span>
          </a><!-- End Messages Icon -->

          <ul class="dropdown-menu dropdown-menu-end dropdown-menu-arrow messages">
            <li class="dropdown-header">
             Size <?php echo $mesajcek; ?> Yeni Mesaj
              <a href="index.php"><span class="badge rounded-pill bg-primary p-2 ms-2">OK PANEL MESAJI</span></a>
            </li>
            <li>
              <hr class="dropdown-divider">
            </li>
            <?php 
$mesajsor=$db->prepare("SELECT * FROM mesajlar LIMIT 2");
$mesajsor->execute();

while ($mesajcek=$mesajsor->fetch(PDO::FETCH_ASSOC)) {

?>
            <li class="message-item">
              <a href="index.php">
                <img src="assets/img/usergif.gif" alt="" class="rounded-circle">
                <div>
                  <h4><?php echo $mesajcek['mesajlar_isim']?></h4>
                  <p><?php echo $mesajcek['mesajlar_konu']?></p>
                  <p></p>
                </div>
              </a>
            </li>
            <li>
              <hr class="dropdown-divider">
            </li>
<?PHP } ?>
            

            <li class="dropdown-footer">
              <a href="index.php">Gelen Mesajlardan İlk 3 Mesaj.</a>
            </li>

          </ul><!-- End Messages Dropdown Items -->

        </li><!-- End Messages Nav -->

        <li class="nav-item dropdown pe-3">

          <a class="nav-link nav-profile d-flex align-items-center pe-0" href="#" data-bs-toggle="dropdown">
            <img src="assets/img/profile-img.jpg" alt="Profile" class="rounded-circle">
            <?php
              $adminsor=$db->prepare("SELECT * FROM admin_ayarlari");
              $adminsor->execute();
              $admincek=$adminsor->fetch(PDO::FETCH_ASSOC);
                 ?>
            <span class="d-none d-md-block dropdown-toggle ps-2"><?php echo $admincek['admin_adi'] ?></span>
          </a><!-- End Profile Iamge Icon -->

          <ul class="dropdown-menu dropdown-menu-end dropdown-menu-arrow profile">
            <li class="dropdown-header">
              <h6><?php echo $admincek['admin_adi'] ?></h6>
              <span>OK Basit Kurumsal</span>
            </li>
            <li>
              <hr class="dropdown-divider">
            </li>

            <li>
              <a class="dropdown-item d-flex align-items-center" href="admin-profil.php">
                <i class="bi bi-person"></i>
                <span>Profili Güncelle</span>
              </a>
            </li>
            <li>
              <hr class="dropdown-divider">
            </li>

            <li>
              <a class="dropdown-item d-flex align-items-center" href="islemler/cikis.php">
                <i class="bi bi-box-arrow-right"></i>
                <span>Çıkış</span>
              </a>
            </li>

          </ul><!-- End Profile Dropdown Items -->
        </li><!-- End Profile Nav -->

      </ul>
    </nav><!-- End Icons Navigation -->

  </header><!-- End Header -->

    <!-- ======= Sidebar ======= -->
    <aside id="sidebar" class="sidebar">

<ul class="sidebar-nav" id="sidebar-nav">

  <li class="nav-item">
    <a class="nav-link " href="index.php">
      <i class="bi bi-grid"></i>
      <span>Kontrol Paneli</span>
    </a>
  </li><!-- End Dashboard Nav -->

  

  

  <li class="nav-heading">Sayfalar</li>

  
  <li class="nav-item">
    <a class="nav-link collapsed" href="sayfaayarlari.php">
      <i class="ri-list-settings-line"></i>
      <span>Sayfa Ayarları</span>
    </a>
  </li>

  <li class="nav-item">
    <a class="nav-link collapsed" href="sliderayarlari.php">
      <i class="ri-list-settings-line"></i>
      <span>Slider Ayarları</span>
    </a>
  </li>

  <li class="nav-item">
    <a class="nav-link collapsed" href="hakkimizdaayarlari.php">
      <i class="ri-list-settings-line"></i>
      <span>Hakkımızda Ayarları</span>
    </a>
  </li>

  <li class="nav-item">
    <a class="nav-link collapsed" href="hizmetayarlari.php">
      <i class="ri-list-settings-line"></i>
      <span>Hizmet Ayarları</span>
    </a>
  </li>

  <li class="nav-item">
    <a class="nav-link collapsed" href="galeriayarlari.php">
      <i class="ri-list-settings-line"></i>
      <span>Galeri Ayarları</span>
    </a>
  </li>

  <li class="nav-item">
    <a class="nav-link collapsed" href="sssayarlari.php">
      <i class="ri-list-settings-line"></i>
      <span>S.S.S Ayarları</span>
    </a>
  </li>

  <li class="nav-item">
    <a class="nav-link collapsed" href="referansayarlari.php">
      <i class="ri-list-settings-line"></i>
      <span>Referans Ayarları</span>
    </a>
  </li>

  <li class="nav-heading">Admin</li>

  <li class="nav-item">
    <a class="nav-link collapsed" href="admin-profil.php">
      <i class="bi bi-person"></i>
      <span>Profil Ayarları</span>
    </a>
  </li><!-- End Profile Page Nav -->
</ul>

</aside><!-- End Sidebar-->
