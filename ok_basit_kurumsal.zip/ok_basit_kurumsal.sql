-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Anamakine: 127.0.0.1
-- Üretim Zamanı: 12 Eki 2022, 13:30:48
-- Sunucu sürümü: 10.4.24-MariaDB
-- PHP Sürümü: 8.1.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Veritabanı: `ok_basit_kurumsal`
--

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `admin_ayarlari`
--

CREATE TABLE `admin_ayarlari` (
  `admin_id` int(11) NOT NULL,
  `admin_adi` varchar(50) NOT NULL,
  `admin_kullanici_adi` varchar(50) NOT NULL,
  `admin_kullanici_sifresi` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Tablo döküm verisi `admin_ayarlari`
--

INSERT INTO `admin_ayarlari` (`admin_id`, `admin_adi`, `admin_kullanici_adi`, `admin_kullanici_sifresi`) VALUES
(1, 'Admin', 'admin', 'admin');

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `galeri_ayarlari`
--

CREATE TABLE `galeri_ayarlari` (
  `galeri_id` int(11) NOT NULL,
  `galeri_resim` varchar(500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Tablo döküm verisi `galeri_ayarlari`
--

INSERT INTO `galeri_ayarlari` (`galeri_id`, `galeri_resim`) VALUES
(4, 'resimler/th4058.jpg'),
(5, 'resimler/lu782.jpg'),
(6, 'resimler/cv7988.jpg');

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `hakkimizda_ayarlari`
--

CREATE TABLE `hakkimizda_ayarlari` (
  `hakkimizda_id` int(11) NOT NULL,
  `hakkimizda_baslik` varchar(250) NOT NULL,
  `hakkimizda_aciklama` varchar(1000) NOT NULL,
  `hakkimizda_resim` varchar(250) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Tablo döküm verisi `hakkimizda_ayarlari`
--

INSERT INTO `hakkimizda_ayarlari` (`hakkimizda_id`, `hakkimizda_baslik`, `hakkimizda_aciklama`, `hakkimizda_resim`) VALUES
(1, 'OK Basit Kurumsal | Hakkımızda', 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum', 'resimler/fg8759.png');

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `hizmet_ayarlari`
--

CREATE TABLE `hizmet_ayarlari` (
  `hizmet_id` int(11) NOT NULL,
  `hizmet_baslik` varchar(50) NOT NULL,
  `hizmet_aciklama` varchar(250) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Tablo döküm verisi `hizmet_ayarlari`
--

INSERT INTO `hizmet_ayarlari` (`hizmet_id`, `hizmet_baslik`, `hizmet_aciklama`) VALUES
(1, 'Örnek Hizmet 1', 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It h'),
(2, 'Örnek Hizmet 2', 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It h'),
(3, 'Örnek Hizmet 3', 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It h'),
(4, 'Örnek Hizmet 4', 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It h');

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `mesajlar`
--

CREATE TABLE `mesajlar` (
  `mesajlar_id` int(11) NOT NULL,
  `mesajlar_isim` varchar(300) NOT NULL,
  `mesajlar_mail` varchar(300) NOT NULL,
  `mesajlar_konu` varchar(300) NOT NULL,
  `mesajlar_mesaj` varchar(500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Tablo döküm verisi `mesajlar`
--

INSERT INTO `mesajlar` (`mesajlar_id`, `mesajlar_isim`, `mesajlar_mail`, `mesajlar_konu`, `mesajlar_mesaj`) VALUES
(2, 'test', 'test@test.com', 'TEST', 'Test mesajı');

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `referans_ayarlari`
--

CREATE TABLE `referans_ayarlari` (
  `referans_id` int(11) NOT NULL,
  `referans_logo` varchar(500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Tablo döküm verisi `referans_ayarlari`
--

INSERT INTO `referans_ayarlari` (`referans_id`, `referans_logo`) VALUES
(4, 'resimler/cv8564.png'),
(5, 'resimler/fg6643.png'),
(6, 'resimler/th3825.png'),
(7, 'resimler/cv1498.png');

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `sayfa_ayarlari`
--

CREATE TABLE `sayfa_ayarlari` (
  `sayfa_ayarlari_id` int(11) NOT NULL,
  `baslik` varchar(50) NOT NULL,
  `slogan` varchar(120) NOT NULL,
  `adres` varchar(450) NOT NULL,
  `tel` varchar(50) NOT NULL,
  `eposta` varchar(50) NOT NULL,
  `twitter` varchar(100) NOT NULL,
  `facebook` varchar(100) NOT NULL,
  `instagram` varchar(100) NOT NULL,
  `skype` varchar(500) NOT NULL,
  `linkedin` varchar(500) NOT NULL,
  `harita` varchar(5050) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Tablo döküm verisi `sayfa_ayarlari`
--

INSERT INTO `sayfa_ayarlari` (`sayfa_ayarlari_id`, `baslik`, `slogan`, `adres`, `tel`, `eposta`, `twitter`, `facebook`, `instagram`, `skype`, `linkedin`, `harita`) VALUES
(1, 'OK Basit Kurumsal', 'OK Basit Kurumsal Slogan Yazısı', 'Şehir / Ülke', '0555 555 55 55', 'demo@demo', 'twitter.com', 'facebook.com', 'instagram.com', 'skype.com', 'linkedin.com', 'https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d387193.305935303!2d-74.25986548248684!3d40.69714941932609!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x89c24fa5d33f083b%3A0xc80b8f06e177fe62!2sNew%20York%2C%20Amerika%20Birle%C5%9Fik%20Devletleri!5e0!3m2!1str!2str!4v1665572907700!5m2!1str!2str');

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `slider_ayarlari`
--

CREATE TABLE `slider_ayarlari` (
  `slider_id` int(11) NOT NULL,
  `slider_baslik` varchar(500) NOT NULL,
  `slider_aciklama` varchar(500) NOT NULL,
  `slider_resim` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Tablo döküm verisi `slider_ayarlari`
--

INSERT INTO `slider_ayarlari` (`slider_id`, `slider_baslik`, `slider_aciklama`, `slider_resim`) VALUES
(1, 'OK Basit Kurumsal', 'Web Scripti | Ücretsiz', 'resimler/lu4570.png');

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `sss_ayarlari`
--

CREATE TABLE `sss_ayarlari` (
  `sss_id` int(11) NOT NULL,
  `sss_soru` varchar(500) NOT NULL,
  `sss_cevap` varchar(750) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Tablo döküm verisi `sss_ayarlari`
--

INSERT INTO `sss_ayarlari` (`sss_id`, `sss_soru`, `sss_cevap`) VALUES
(1, 'Örnek Soru ?', 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum');

--
-- Dökümü yapılmış tablolar için indeksler
--

--
-- Tablo için indeksler `admin_ayarlari`
--
ALTER TABLE `admin_ayarlari`
  ADD PRIMARY KEY (`admin_id`);

--
-- Tablo için indeksler `galeri_ayarlari`
--
ALTER TABLE `galeri_ayarlari`
  ADD PRIMARY KEY (`galeri_id`);

--
-- Tablo için indeksler `hakkimizda_ayarlari`
--
ALTER TABLE `hakkimizda_ayarlari`
  ADD PRIMARY KEY (`hakkimizda_id`);

--
-- Tablo için indeksler `hizmet_ayarlari`
--
ALTER TABLE `hizmet_ayarlari`
  ADD PRIMARY KEY (`hizmet_id`);

--
-- Tablo için indeksler `mesajlar`
--
ALTER TABLE `mesajlar`
  ADD PRIMARY KEY (`mesajlar_id`);

--
-- Tablo için indeksler `referans_ayarlari`
--
ALTER TABLE `referans_ayarlari`
  ADD PRIMARY KEY (`referans_id`);

--
-- Tablo için indeksler `sayfa_ayarlari`
--
ALTER TABLE `sayfa_ayarlari`
  ADD PRIMARY KEY (`sayfa_ayarlari_id`);

--
-- Tablo için indeksler `slider_ayarlari`
--
ALTER TABLE `slider_ayarlari`
  ADD PRIMARY KEY (`slider_id`);

--
-- Tablo için indeksler `sss_ayarlari`
--
ALTER TABLE `sss_ayarlari`
  ADD PRIMARY KEY (`sss_id`);

--
-- Dökümü yapılmış tablolar için AUTO_INCREMENT değeri
--

--
-- Tablo için AUTO_INCREMENT değeri `admin_ayarlari`
--
ALTER TABLE `admin_ayarlari`
  MODIFY `admin_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- Tablo için AUTO_INCREMENT değeri `galeri_ayarlari`
--
ALTER TABLE `galeri_ayarlari`
  MODIFY `galeri_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- Tablo için AUTO_INCREMENT değeri `hakkimizda_ayarlari`
--
ALTER TABLE `hakkimizda_ayarlari`
  MODIFY `hakkimizda_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- Tablo için AUTO_INCREMENT değeri `hizmet_ayarlari`
--
ALTER TABLE `hizmet_ayarlari`
  MODIFY `hizmet_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- Tablo için AUTO_INCREMENT değeri `mesajlar`
--
ALTER TABLE `mesajlar`
  MODIFY `mesajlar_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- Tablo için AUTO_INCREMENT değeri `referans_ayarlari`
--
ALTER TABLE `referans_ayarlari`
  MODIFY `referans_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- Tablo için AUTO_INCREMENT değeri `sayfa_ayarlari`
--
ALTER TABLE `sayfa_ayarlari`
  MODIFY `sayfa_ayarlari_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- Tablo için AUTO_INCREMENT değeri `slider_ayarlari`
--
ALTER TABLE `slider_ayarlari`
  MODIFY `slider_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- Tablo için AUTO_INCREMENT değeri `sss_ayarlari`
--
ALTER TABLE `sss_ayarlari`
  MODIFY `sss_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
